/**
 * server.js — نقطة الدخول: يشغّل واجهة API، يخدم الواجهة الأمامية،
 * ويشغّل محرك الخلفية الذي يجلب البيانات الحقيقية بشكل دوري ويخزنها ويرسل تنبيهات Telegram.
 */
require("dotenv").config();
const express = require("express");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const path = require("path");

const db = require("./db");
const {
  hashPassword,
  verifyPassword,
  signToken,
  setAuthCookie,
  clearAuthCookie,
  authRequired,
  authOptional,
} = require("./auth");
const { sendTelegramAlert } = require("./telegram");
const engine = require("./riskEngine");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(express.json());
app.use(cookieParser());
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || true, credentials: true }));
app.use(express.static(path.join(__dirname, "..", "frontend")));

/* ==========================================================================
   1) مسارات المصادقة (تسجيل الدخول)
   ========================================================================== */
app.post("/api/auth/register", (req, res) => {
  const { username, password } = req.body || {};
  if (!username || typeof username !== "string" || username.length < 3) {
    return res.status(400).json({ error: "اسم مستخدم غير صالح (3 أحرف على الأقل)" });
  }
  if (!password || password.length < 6) {
    return res.status(400).json({ error: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" });
  }
  const exists = db.prepare("SELECT id FROM users WHERE username = ?").get(username);
  if (exists) return res.status(409).json({ error: "اسم المستخدم مستخدم بالفعل" });

  const info = db
    .prepare("INSERT INTO users (username, password_hash) VALUES (?, ?)")
    .run(username, hashPassword(password));
  const user = { id: info.lastInsertRowid, username };
  setAuthCookie(res, signToken(user));
  res.json({ user });
});

app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body || {};
  const row = db.prepare("SELECT * FROM users WHERE username = ?").get(username || "");
  if (!row || !verifyPassword(password || "", row.password_hash)) {
    return res.status(401).json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة" });
  }
  const user = { id: row.id, username: row.username };
  setAuthCookie(res, signToken(user));
  res.json({ user });
});

app.post("/api/auth/logout", (req, res) => {
  clearAuthCookie(res);
  res.json({ ok: true });
});

app.get("/api/auth/me", authOptional, (req, res) => {
  res.json({ user: req.user || null });
});

/* ==========================================================================
   2) واجهة برمجية (API) عامة للقراءة — لا تتطلب تسجيل دخول
   ========================================================================== */
app.get("/api/hotspots", (req, res) => {
  const rows = db.prepare("SELECT * FROM hotspots ORDER BY id").all();
  const weights = db.prepare("SELECT * FROM weights WHERE id = 1").get();
  const hotspots = rows.map((h) => ({
    ...h,
    risk: engine.computeTotalSeismicRiskIndex(h, weights),
  }));
  res.json({ hotspots, weights });
});

app.get("/api/hotspots/:id/history", (req, res) => {
  const hours = Math.min(Number(req.query.hours) || 168, 24 * 60);
  const since = Date.now() - hours * 3600 * 1000;
  const rows = db
    .prepare(
      "SELECT ts, tectonic, astro, thermal, pressure, risk FROM readings WHERE hotspot_id = ? AND ts >= ? ORDER BY ts ASC"
    )
    .all(req.params.id, since);
  res.json({ history: rows });
});

app.get("/api/weights", (req, res) => {
  res.json(db.prepare("SELECT * FROM weights WHERE id = 1").get());
});

app.get("/api/alerts", (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 30, 200);
  res.json({ alerts: db.prepare("SELECT * FROM alerts ORDER BY id DESC LIMIT ?").all(limit) });
});

/* ==========================================================================
   3) واجهة برمجية محمية — تتطلب تسجيل دخول
   ========================================================================== */
app.put("/api/weights", authRequired, (req, res) => {
  const { tectonic, astro, thermal, pressure } = req.body || {};
  const nums = [tectonic, astro, thermal, pressure].map(Number);
  if (nums.some((n) => Number.isNaN(n) || n < 0)) {
    return res.status(400).json({ error: "قيم أوزان غير صالحة" });
  }
  db.prepare("UPDATE weights SET tectonic=?, astro=?, thermal=?, pressure=?, updated_by=? WHERE id=1").run(
    nums[0],
    nums[1],
    nums[2],
    nums[3],
    req.user.username
  );
  res.json({ ok: true });
});

app.post("/api/alerts/test", authRequired, async (req, res) => {
  const sent = await sendTelegramAlert(`🔔 رسالة اختبار من Seismic Nexus بواسطة ${req.user.username}`);
  res.json({ sent });
});

/* ==========================================================================
   4) محرك الخلفية: يعمل بشكل مستقل عن أي طلب متصفح
   ========================================================================== */
let lastLevels = {};
let seenQuakeIds = new Set();

async function refreshHotspotsFromUSGS() {
  try {
    const fresh = await engine.fetchHotspotsFromUSGS();
    const upsert = db.prepare(`
      INSERT INTO hotspots (id, name, lat, lng, sensitivity, recent_mag, recent_time, depth, tectonic)
      VALUES (@id, @name, @lat, @lng, @sensitivity, @recent_mag, @recent_time, @depth, @tectonic)
      ON CONFLICT(id) DO UPDATE SET
        name=excluded.name, lat=excluded.lat, lng=excluded.lng,
        recent_mag=excluded.recent_mag, recent_time=excluded.recent_time,
        depth=excluded.depth, tectonic=excluded.tectonic, updated_at=datetime('now')
    `);
    db.transaction((list) => list.forEach((h) => upsert.run(h)))(fresh);
    console.log(`[USGS] تحديث ${fresh.length} بؤرة من بيانات حقيقية`);
  } catch (err) {
    console.error("[USGS] فشل التحديث:", err.message);
  }
}

async function refreshWeather() {
  const rows = db.prepare("SELECT * FROM hotspots").all();
  for (const h of rows) {
    try {
      const w = await engine.fetchWeatherForHotspot(h.lat, h.lng);
      db.prepare(
        `UPDATE hotspots SET thermal=?, pressure=?, current_temp=?, current_pressure=?,
         thermal_anomaly=?, pressure_drop=?, updated_at=datetime('now') WHERE id=?`
      ).run(w.thermal, w.pressure, w.currentTemp, w.currentPressure, w.thermalAnomaly, w.pressureDrop, h.id);
    } catch (err) {
      console.warn(`[Weather] فشل جلب بيانات ${h.name}:`, err.message);
    }
  }
}

function tickAstroAndPersist() {
  const globalAstro = engine.computeAstroAlignment(new Date());
  const rows = db.prepare("SELECT * FROM hotspots").all();
  const weights = db.prepare("SELECT * FROM weights WHERE id = 1").get();
  const insertReading = db.prepare(
    "INSERT INTO readings (hotspot_id, ts, tectonic, astro, thermal, pressure, risk) VALUES (?,?,?,?,?,?,?)"
  );
  const updateAstro = db.prepare("UPDATE hotspots SET astro=? WHERE id=?");

  const tx = db.transaction(() => {
    rows.forEach((h) => {
      const astro = Math.max(0, Math.min(100, globalAstro * h.sensitivity));
      updateAstro.run(astro, h.id);
      const factors = { tectonic: h.tectonic, astro, thermal: h.thermal, pressure: h.pressure };
      const risk = engine.computeTotalSeismicRiskIndex(factors, weights);
      insertReading.run(h.id, Date.now(), h.tectonic, astro, h.thermal, h.pressure, risk);
      checkAlert(h, risk);
    });
  });
  tx();
}

function checkAlert(h, risk) {
  const lvl = engine.riskLevel(risk);
  const prev = lastLevels[h.id];
  lastLevels[h.id] = lvl.cls;
  if (prev && prev !== lvl.cls && (lvl.cls === "warn" || lvl.cls === "danger")) {
    const label = lvl.cls === "danger" ? "حرجة" : "برتقالية";
    const message = `تحذير درجة "${label}": ارتفاع مؤشر الخطر المحسوب عند ${h.name} إلى ${Math.round(risk)}%.`;
    const info = db
      .prepare("INSERT INTO alerts (hotspot_id, level, message) VALUES (?,?,?)")
      .run(h.id, lvl.cls === "danger" ? "red" : "orange", message);
    sendTelegramAlert(`⚠️ <b>Seismic Nexus</b>\n${message}`).then((ok) => {
      if (ok) db.prepare("UPDATE alerts SET telegram_sent=1 WHERE id=?").run(info.lastInsertRowid);
    });
  }
}

async function pollNewQuakes() {
  try {
    const quakes = await engine.fetchRecentDayQuakes();
    const hotspots = db.prepare("SELECT * FROM hotspots").all();
    quakes.forEach((q) => {
      if (seenQuakeIds.has(q.id)) return;
      seenQuakeIds.add(q.id);
      hotspots.forEach((h) => {
        if (engine.haversineKm(h.lat, h.lng, q.lat, q.lon) < 400) {
          const message = `🌍 زلزال حقيقي جديد (المصدر: USGS): قوة ${q.mag.toFixed(1)} بالقرب من ${h.name} — ${
            q.place || ""
          }.`;
          const info = db
            .prepare("INSERT INTO alerts (hotspot_id, level, message) VALUES (?,?,?)")
            .run(h.id, q.mag >= 5 ? "red" : "orange", message);
          sendTelegramAlert(`🌍 <b>Seismic Nexus</b>\n${message}`).then((ok) => {
            if (ok) db.prepare("UPDATE alerts SET telegram_sent=1 WHERE id=?").run(info.lastInsertRowid);
          });
        }
      });
    });
  } catch (err) {
    console.error("[USGS يومي] خطأ:", err.message);
  }
}

async function bootstrapBackgroundJobs() {
  await refreshHotspotsFromUSGS();
  await refreshWeather();
  tickAstroAndPersist();

  setInterval(refreshHotspotsFromUSGS, 15 * 60 * 1000); // كل 15 دقيقة: تحديث البؤر من USGS
  setInterval(refreshWeather, 5 * 60 * 1000); // كل 5 دقائق: تحديث الطقس الحقيقي
  setInterval(tickAstroAndPersist, 60 * 1000); // كل دقيقة: حساب الفلك + حفظ قراءة تاريخية + فحص تنبيهات
  setInterval(pollNewQuakes, 3 * 60 * 1000); // كل 3 دقائق: فحص زلازل حقيقية جديدة
  pollNewQuakes();
}

app.listen(PORT, () => {
  console.log(`✅ Seismic Nexus API يعمل على http://localhost:${PORT}`);
  bootstrapBackgroundJobs();
});
