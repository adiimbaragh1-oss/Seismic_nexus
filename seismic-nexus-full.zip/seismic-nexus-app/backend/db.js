/**
 * db.js — طبقة قاعدة البيانات (SQLite عبر better-sqlite3)
 *
 * لماذا SQLite؟ لا يحتاج تثبيت خادم قاعدة بيانات منفصل، ويعمل مباشرة من ملف
 * واحد (seismic.db) بجانب الكود. للانتقال إلى PostgreSQL لاحقاً:
 *   - استبدل هذا الملف بإعداد Pool من مكتبة "pg"
 *   - بدّل AUTOINCREMENT بـ SERIAL / GENERATED ALWAYS AS IDENTITY
 *   - استعلامات SELECT/INSERT/UPDATE أدناه متوافقة تقريباً بصياغة SQL القياسية
 */
const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(path.join(__dirname, "seismic.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at    TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS hotspots (
  id                INTEGER PRIMARY KEY,
  name              TEXT NOT NULL,
  lat               REAL NOT NULL,
  lng               REAL NOT NULL,
  sensitivity       REAL NOT NULL DEFAULT 1.0,
  recent_mag        REAL,
  recent_time       INTEGER,
  depth             REAL,
  tectonic          REAL DEFAULT 0,
  astro             REAL DEFAULT 0,
  thermal           REAL DEFAULT 0,
  pressure          REAL DEFAULT 0,
  current_temp      REAL,
  current_pressure  REAL,
  thermal_anomaly   REAL,
  pressure_drop     REAL,
  updated_at        TEXT DEFAULT (datetime('now'))
);

-- سجل تاريخي: قراءة واحدة لكل بؤرة تُخزَّن دورياً لأغراض التحليل والرسوم البيانية
CREATE TABLE IF NOT EXISTS readings (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  hotspot_id  INTEGER NOT NULL,
  ts          INTEGER NOT NULL,
  tectonic    REAL, astro REAL, thermal REAL, pressure REAL, risk REAL,
  FOREIGN KEY (hotspot_id) REFERENCES hotspots(id)
);
CREATE INDEX IF NOT EXISTS idx_readings_hotspot_ts ON readings(hotspot_id, ts);

CREATE TABLE IF NOT EXISTS alerts (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  hotspot_id     INTEGER,
  level          TEXT NOT NULL,
  message        TEXT NOT NULL,
  ts             TEXT DEFAULT (datetime('now')),
  telegram_sent  INTEGER DEFAULT 0
);

-- صف واحد فقط: أوزان العوامل الحالية المشتركة بين كل المستخدمين
CREATE TABLE IF NOT EXISTS weights (
  id         INTEGER PRIMARY KEY CHECK (id = 1),
  tectonic   REAL NOT NULL DEFAULT 50,
  astro      REAL NOT NULL DEFAULT 25,
  thermal    REAL NOT NULL DEFAULT 15,
  pressure   REAL NOT NULL DEFAULT 10,
  updated_by TEXT
);
INSERT OR IGNORE INTO weights (id, tectonic, astro, thermal, pressure) VALUES (1, 50, 25, 15, 10);
`);

module.exports = db;
