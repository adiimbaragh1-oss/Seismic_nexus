/**
 * auth.js — تسجيل الدخول: تشفير كلمات المرور (bcrypt) وجلسات JWT عبر كوكي httpOnly
 */
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
const TOKEN_COOKIE = "sn_token";
const isProd = process.env.NODE_ENV === "production";

function hashPassword(password) {
  return bcrypt.hashSync(password, 10);
}

function verifyPassword(password, hash) {
  return bcrypt.compareSync(password, hash);
}

function signToken(user) {
  return jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: "7d" });
}

function setAuthCookie(res, token) {
  res.cookie(TOKEN_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: isProd, // يتطلب HTTPS في الإنتاج
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
}

function clearAuthCookie(res) {
  res.clearCookie(TOKEN_COOKIE);
}

// middleware: يرفض الطلب إن لم يكن المستخدم مسجّل دخول (للعمليات الحساسة مثل تعديل الأوزان)
function authRequired(req, res, next) {
  const token = req.cookies[TOKEN_COOKIE];
  if (!token) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "جلسة غير صالحة أو منتهية، الرجاء تسجيل الدخول مجدداً" });
  }
}

// middleware: يقرأ المستخدم إن كان مسجلاً دخوله لكن لا يرفض الطلب إن لم يكن (للمسارات العامة)
function authOptional(req, res, next) {
  const token = req.cookies[TOKEN_COOKIE];
  if (token) {
    try {
      req.user = jwt.verify(token, JWT_SECRET);
    } catch {
      /* تجاهل التوكن غير الصالح، المستخدم يبقى غير مسجل */
    }
  }
  next();
}

module.exports = {
  hashPassword,
  verifyPassword,
  signToken,
  setAuthCookie,
  clearAuthCookie,
  authRequired,
  authOptional,
  TOKEN_COOKIE,
};
