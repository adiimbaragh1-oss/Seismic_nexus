/**
 * telegram.js — إرسال تنبيهات فورية عبر Telegram Bot API
 * يتطلب TELEGRAM_BOT_TOKEN و TELEGRAM_CHAT_ID في ملف .env
 * إن لم تُضبط القيم، تُطبع رسالة تحذير في الطرفية ويُتجاوز الإرسال دون كسر التطبيق
 */
async function sendTelegramAlert(message) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.warn("[Telegram] لم يتم ضبط TELEGRAM_BOT_TOKEN/TELEGRAM_CHAT_ID — تم تجاوز إرسال التنبيه.");
    return false;
  }

  try {
    const url = `https://api.telegram.org/bot${token}/sendMessage`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: message, parse_mode: "HTML" }),
    });
    const data = await res.json();
    if (!data.ok) console.warn("[Telegram] فشل الإرسال:", data.description);
    return !!data.ok;
  } catch (err) {
    console.warn("[Telegram] خطأ في الاتصال:", err.message);
    return false;
  }
}

module.exports = { sendTelegramAlert };
