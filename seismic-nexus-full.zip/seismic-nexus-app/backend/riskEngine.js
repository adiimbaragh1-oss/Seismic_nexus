/**
 * riskEngine.js — المنطق العلمي/الحسابي بالكامل، بمعزل عن الخادم وقاعدة البيانات
 * يشمل: الدالة الأساسية لحساب مؤشر الخطر، جلب الزلازل الحقيقية (USGS)،
 * جلب الطقس الحقيقي (Open-Meteo)، وحساب محاذاة الكواكب الفعلية فلكياً.
 */

const USGS_MONTH_URL = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_month.geojson";
const USGS_DAY_URL = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson";

const openMeteoUrl = (lat, lon) =>
  `https://api.open-meteo.com/v1/forecast?latitude=${lat.toFixed(3)}&longitude=${lon.toFixed(3)}` +
  `&current=temperature_2m,surface_pressure&hourly=temperature_2m,surface_pressure` +
  `&past_days=7&forecast_days=1&timezone=UTC`;

/* -----------------------------------------------------------------------
   ###  الدالة الأساسية المطلوبة: مؤشر الخطر الزلزالي الإجمالي (0-100%)  ###
   ----------------------------------------------------------------------- */
const DEFAULT_WEIGHTS = { tectonic: 50, astro: 25, thermal: 15, pressure: 10 };

function normalizeWeights(w) {
  const sum = w.tectonic + w.astro + w.thermal + w.pressure;
  if (sum <= 0) return { tectonic: 0, astro: 0, thermal: 0, pressure: 0 };
  return {
    tectonic: w.tectonic / sum,
    astro: w.astro / sum,
    thermal: w.thermal / sum,
    pressure: w.pressure / sum,
  };
}

function computeTotalSeismicRiskIndex(factors, rawWeights) {
  const w = normalizeWeights(rawWeights);
  const score =
    factors.tectonic * w.tectonic +
    factors.astro * w.astro +
    factors.thermal * w.thermal +
    factors.pressure * w.pressure;
  return Math.max(0, Math.min(100, score));
}

function riskLevel(score) {
  if (score >= 66) return { label: "حرج", cls: "danger" };
  if (score >= 33) return { label: "متوسط", cls: "warn" };
  return { label: "منخفض", cls: "safe" };
}

/* -----------------------------------------------------------------------
   محاذاة فلكية حقيقية — عناصر مدارية تقريبية عند حقبة J2000
   ----------------------------------------------------------------------- */
const PLANETS = [
  { name: "Mercury", L0: 252.251, period: 87.969 },
  { name: "Venus", L0: 181.98, period: 224.701 },
  { name: "Earth", L0: 100.464, period: 365.256 },
  { name: "Mars", L0: 355.453, period: 686.98 },
  { name: "Jupiter", L0: 34.404, period: 4332.589 },
  { name: "Saturn", L0: 50.076, period: 10759.22 },
];
const J2000_MS = Date.UTC(2000, 0, 1, 12, 0, 0);

function planetLongitudeNow(planet, date) {
  const daysSinceJ2000 = (date.getTime() - J2000_MS) / 86400000;
  let L = (planet.L0 + (360 / planet.period) * daysSinceJ2000) % 360;
  if (L < 0) L += 360;
  return L;
}

function computeAstroAlignment(date) {
  const angles = PLANETS.map((p) => planetLongitudeNow(p, date));
  const diffs = [];
  for (let i = 0; i < angles.length; i++) {
    for (let j = i + 1; j < angles.length; j++) {
      let d = Math.abs(angles[i] - angles[j]);
      d = Math.min(d, 360 - d);
      diffs.push(d);
    }
  }
  const avg = diffs.reduce((a, b) => a + b, 0) / diffs.length;
  return Math.max(0, Math.min(100, 100 - (avg / 95) * 100));
}

/* -----------------------------------------------------------------------
   أدوات مساعدة
   ----------------------------------------------------------------------- */
function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371,
    toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1),
    dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

function mapRange(v, inMin, inMax, outMin = 0, outMax = 100) {
  const c = Math.max(inMin, Math.min(inMax, v));
  return ((c - inMin) / (inMax - inMin)) * (outMax - outMin) + outMin;
}

/* -----------------------------------------------------------------------
   جلب البؤر من زلازل USGS الحقيقية (آخر 30 يوماً) + مؤشر النشاط التاريخي
   ----------------------------------------------------------------------- */
async function fetchHotspotsFromUSGS() {
  const res = await fetch(USGS_MONTH_URL);
  if (!res.ok) throw new Error("USGS fetch failed: " + res.status);
  const data = await res.json();

  const quakes = data.features
    .map((f) => ({
      id: f.id,
      mag: f.properties.mag,
      place: f.properties.place,
      time: f.properties.time,
      lon: f.geometry.coordinates[0],
      lat: f.geometry.coordinates[1],
      depth: f.geometry.coordinates[2],
    }))
    .filter((q) => q.mag != null && q.lat != null);

  const sorted = [...quakes].sort((a, b) => b.mag - a.mag);
  const chosen = [];
  for (const q of sorted) {
    if (chosen.length >= 8) break;
    const tooClose = chosen.some((c) => haversineKm(c.lat, c.lon, q.lat, q.lon) < 500);
    if (!tooClose) chosen.push(q);
  }

  const rawEnergies = chosen.map((h) => {
    const nearby = quakes.filter((q) => haversineKm(h.lat, h.lon, q.lat, q.lon) < 300);
    return nearby.reduce((sum, q) => sum + Math.pow(10, 1.5 * q.mag), 0);
  });
  const logEnergies = rawEnergies.map((e) => Math.log10(e + 1));
  const minE = Math.min(...logEnergies),
    maxE = Math.max(...logEnergies);

  return chosen.map((q, i) => ({
    id: i + 1,
    name: `بؤرة #${i + 1} — ${q.place || "موقع غير محدد"}`,
    lat: q.lat,
    lng: q.lon,
    sensitivity: 0.9 + (i % 4) * 0.08,
    recent_mag: q.mag,
    recent_time: q.time,
    depth: q.depth,
    tectonic: maxE > minE ? mapRange(logEnergies[i], minE, maxE, 8, 100) : 40,
  }));
}

/* -----------------------------------------------------------------------
   جلب الطقس الحقيقي (Open-Meteo) لموقع بؤرة معينة
   ----------------------------------------------------------------------- */
async function fetchWeatherForHotspot(lat, lng) {
  const res = await fetch(openMeteoUrl(lat, lng));
  if (!res.ok) throw new Error("Open-Meteo fetch failed: " + res.status);
  const data = await res.json();

  const temps = data.hourly.temperature_2m;
  const pressures = data.hourly.surface_pressure;

  const validTemps = temps.filter((t) => t != null);
  const validPress = pressures.filter((p) => p != null);
  const avgTemp = validTemps.reduce((a, b) => a + b, 0) / validTemps.length;
  const avgPressure = validPress.reduce((a, b) => a + b, 0) / validPress.length;

  const currentTemp = data.current.temperature_2m;
  const currentPressure = data.current.surface_pressure;
  const thermalAnomaly = currentTemp - avgTemp;
  const pressureDrop = avgPressure - currentPressure;

  return {
    thermal: mapRange(thermalAnomaly, -3, 6, 0, 100),
    pressure: mapRange(pressureDrop, -5, 12, 0, 100),
    currentTemp,
    currentPressure,
    thermalAnomaly,
    pressureDrop,
  };
}

/* -----------------------------------------------------------------------
   فحص زلازل حقيقية جديدة (آخر 24 ساعة) لأغراض تنبيهات Telegram الفورية
   ----------------------------------------------------------------------- */
async function fetchRecentDayQuakes() {
  const res = await fetch(USGS_DAY_URL);
  if (!res.ok) throw new Error("USGS day fetch failed: " + res.status);
  const data = await res.json();
  return data.features
    .map((f) => ({
      id: f.id,
      mag: f.properties.mag,
      place: f.properties.place,
      lat: f.geometry.coordinates[1],
      lon: f.geometry.coordinates[0],
    }))
    .filter((q) => q.mag != null);
}

module.exports = {
  DEFAULT_WEIGHTS,
  normalizeWeights,
  computeTotalSeismicRiskIndex,
  riskLevel,
  computeAstroAlignment,
  haversineKm,
  mapRange,
  fetchHotspotsFromUSGS,
  fetchWeatherForHotspot,
  fetchRecentDayQuakes,
};
