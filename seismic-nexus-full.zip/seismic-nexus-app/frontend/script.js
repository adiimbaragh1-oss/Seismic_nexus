/* ==========================================================================
   Seismic Nexus — الواجهة الأمامية
   كل البيانات الآن تأتي من خادمنا الخاص (Node.js + Express + SQLite) الذي
   يجلب بدوره بيانات حقيقية من USGS و Open-Meteo ويحسب مؤشر الخطر ويخزّن
   التاريخ ويرسل تنبيهات Telegram من جهة الخادم.
   ========================================================================== */

const API = ""; // نفس الأصل (الخادم يقدّم الواجهة والـ API معاً). عدّل هذا إن شغّلت الواجهة من أصل مختلف.

function riskLevel(score) {
  if (score >= 66) return { label: "حرج", cls: "danger" };
  if (score >= 33) return { label: "متوسط", cls: "warn" };
  return { label: "منخفض", cls: "safe" };
}
function normalizeWeights(w) {
  const sum = w.tectonic + w.astro + w.thermal + w.pressure;
  if (sum <= 0) return { tectonic: 0, astro: 0, thermal: 0, pressure: 0 };
  return { tectonic: w.tectonic / sum, astro: w.astro / sum, thermal: w.thermal / sum, pressure: w.pressure / sum };
}
function computeTotalSeismicRiskIndex(factors, rawWeights) {
  const w = normalizeWeights(rawWeights);
  const score = factors.tectonic * w.tectonic + factors.astro * w.astro + factors.thermal * w.thermal + factors.pressure * w.pressure;
  return Math.max(0, Math.min(100, score));
}
const colorFor = cls => (cls === "danger" ? "#ff4d5e" : cls === "warn" ? "#ffb340" : "#3ddc84");

let hotspots = [];
let weights = { tectonic: 50, astro: 25, thermal: 15, pressure: 10 };
let selectedId = null;
let currentUser = null;
let globalRiskForTrace = 20;

/* ==========================================================================
   1) طبقة الاتصال بالـ API الخاص بنا
   ========================================================================== */
async function api(path, opts = {}) {
  const res = await fetch(API + path, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

const fetchHotspots = () => api("/api/hotspots");
const fetchHistory = id => api(`/api/hotspots/${id}/history?hours=168`);
const fetchAlerts = () => api("/api/alerts?limit=30");
const fetchMe = () => api("/api/auth/me");
const login = (username, password) => api("/api/auth/login", { method: "POST", body: JSON.stringify({ username, password }) });
const register = (username, password) => api("/api/auth/register", { method: "POST", body: JSON.stringify({ username, password }) });
const logout = () => api("/api/auth/logout", { method: "POST" });
const saveWeights = w => api("/api/weights", { method: "PUT", body: JSON.stringify(w) });

/* ==========================================================================
   2) المصادقة (تسجيل الدخول / حساب جديد)
   ========================================================================== */
const authModal = document.getElementById("auth-modal");
const loginBtn = document.getElementById("login-btn");
const authBox = document.getElementById("auth-box");

function openAuthModal() { authModal.classList.remove("hidden"); }
function closeAuthModal() { authModal.classList.add("hidden"); }

document.getElementById("auth-modal-close").addEventListener("click", closeAuthModal);
authModal.addEventListener("click", e => { if (e.target === authModal) closeAuthModal(); });

document.querySelectorAll(".modal-tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".modal-tab").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    const isLogin = tab.dataset.tab === "login";
    document.getElementById("login-form").classList.toggle("hidden", !isLogin);
    document.getElementById("register-form").classList.toggle("hidden", isLogin);
  });
});

document.getElementById("login-form").addEventListener("submit", async e => {
  e.preventDefault();
  const username = document.getElementById("login-username").value.trim();
  const password = document.getElementById("login-password").value;
  const errEl = document.getElementById("login-error");
  errEl.textContent = "";
  try {
    const { user } = await login(username, password);
    onAuthChanged(user);
    closeAuthModal();
  } catch (err) {
    errEl.textContent = err.message;
  }
});

document.getElementById("register-form").addEventListener("submit", async e => {
  e.preventDefault();
  const username = document.getElementById("register-username").value.trim();
  const password = document.getElementById("register-password").value;
  const errEl = document.getElementById("register-error");
  errEl.textContent = "";
  try {
    const { user } = await register(username, password);
    onAuthChanged(user);
    closeAuthModal();
  } catch (err) {
    errEl.textContent = err.message;
  }
});

function onAuthChanged(user) {
  currentUser = user;
  renderAuthBox();
  updateSlidersLockState();
}

function renderAuthBox() {
  if (currentUser) {
    authBox.innerHTML = `
      <div class="auth-user">مرحباً، <strong>${currentUser.username}</strong></div>
      <button class="btn-ghost" id="logout-btn">خروج</button>
    `;
    document.getElementById("logout-btn").addEventListener("click", async () => {
      await logout().catch(() => {});
      onAuthChanged(null);
    });
  } else {
    authBox.innerHTML = `<button class="btn-ghost" id="login-btn">تسجيل الدخول</button>`;
    document.getElementById("login-btn").addEventListener("click", openAuthModal);
  }
}

function updateSlidersLockState() {
  const locked = !currentUser;
  ["wt-tectonic", "wt-astro", "wt-thermal", "wt-pressure"].forEach(id => {
    document.getElementById(id).disabled = locked;
  });
  document.getElementById("weights-auth-note").style.display = locked ? "block" : "none";
}

/* ==========================================================================
   3) الخريطة (Leaflet)
   ========================================================================== */
const map = L.map("map", { zoomControl: true, attributionControl: false, worldCopyJump: true }).setView([15, 20], 2);
L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", { maxZoom: 8 }).addTo(map);
const markers = {};

function buildMapMarkers() {
  hotspots.forEach(h => {
    const icon = L.divIcon({
      className: "quake-marker",
      html: `<div class="ring" style="color:${colorFor("safe")}"></div><div class="core" style="background:${colorFor("safe")}"></div>`,
      iconSize: [14, 14],
    });
    const marker = L.marker([h.lat, h.lng], { icon }).addTo(map);
    marker.bindPopup("");
    marker.on("click", () => selectHotspot(h.id));
    markers[h.id] = marker;
  });
}

function updateMap() {
  hotspots.forEach(h => {
    const risk = computeTotalSeismicRiskIndex(h, weights);
    const lvl = riskLevel(risk);
    const c = colorFor(lvl.cls);
    const el = markers[h.id] && markers[h.id].getElement();
    if (el) {
      const ring = el.querySelector(".ring");
      const core = el.querySelector(".core");
      if (ring) ring.style.color = c;
      if (core) core.style.background = c;
    }
    const when = h.recent_time ? new Date(h.recent_time).toLocaleDateString("en-GB") : "—";
    if (markers[h.id]) {
      markers[h.id].setPopupContent(
        `<b>${h.name}</b><br>آخر زلزال حقيقي: M${h.recent_mag?.toFixed(1) ?? "—"} بتاريخ ${when}<br>مؤشر الخطر المحسوب: ${Math.round(risk)}% (${lvl.label})`
      );
    }
  });
}

/* ==========================================================================
   4) الرسوم البيانية
   ========================================================================== */
Chart.defaults.color = "#7b8494";
Chart.defaults.font.family = "'JetBrains Mono', monospace";
Chart.defaults.font.size = 10.5;

const pieChart = new Chart(document.getElementById("pie-chart"), {
  type: "doughnut",
  data: {
    labels: ["النشاط الزلزالي التاريخي", "الفلكي", "الحراري", "الضغط الجوي"],
    datasets: [{ data: [50, 25, 15, 10], backgroundColor: ["#ff9d3d", "#52c7ea", "#ff4d5e", "#9b8cff"], borderColor: "#12161c", borderWidth: 2 }],
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: {
      legend: { position: "bottom", labels: { boxWidth: 10, padding: 12, font: { size: 10.5 } } },
      tooltip: { callbacks: { label: ctx => `${ctx.label}: ${ctx.parsed.toFixed(1)}%` } },
    },
  },
});

const lineChart = new Chart(document.getElementById("line-chart"), {
  type: "line",
  data: {
    labels: [],
    datasets: [
      { label: "شذوذ الحرارة الفعلي", data: [], borderColor: "#ff9d3d", backgroundColor: "rgba(255,157,61,0.12)", tension: 0.3, pointRadius: 0, yAxisID: "y", fill: true, borderWidth: 2 },
      { label: "هبوط الضغط الفعلي", data: [], borderColor: "#9b8cff", backgroundColor: "rgba(155,140,255,0.1)", tension: 0.3, pointRadius: 0, yAxisID: "y1", fill: true, borderWidth: 2 },
    ],
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    interaction: { mode: "index", intersect: false },
    scales: {
      x: { type: "time", time: { unit: "day" }, grid: { color: "#1a2028" }, ticks: { maxTicksLimit: 7 } },
      y: { position: "left", min: 0, max: 100, grid: { color: "#1a2028" }, title: { display: true, text: "thermal factor", font: { size: 10 } } },
      y1: { position: "right", min: 0, max: 100, grid: { display: false }, title: { display: true, text: "pressure factor", font: { size: 10 } } },
    },
    plugins: { legend: { position: "top", labels: { boxWidth: 10, padding: 14, font: { size: 10.5 } } } },
  },
});

async function updateCharts() {
  const h = hotspots.find(s => s.id === selectedId);
  if (!h) return;
  const w = normalizeWeights(weights);
  pieChart.data.datasets[0].data = [h.tectonic * w.tectonic, h.astro * w.astro, h.thermal * w.thermal, h.pressure * w.pressure];
  pieChart.update("none");

  try {
    const { history } = await fetchHistory(h.id);
    lineChart.data.datasets[0].data = history.map(p => ({ x: p.ts, y: p.thermal }));
    lineChart.data.datasets[1].data = history.map(p => ({ x: p.ts, y: p.pressure }));
    lineChart.update("none");
  } catch (err) {
    console.warn("history fetch failed", err);
  }

  document.getElementById("chart-hotspot-name").textContent = h.name;
}

/* ==========================================================================
   5) البوابة التناظرية (SVG Gauge)
   ========================================================================== */
const gaugeSvg = document.getElementById("gauge-svg");
function buildGaugeStatic() {
  const ns = "http://www.w3.org/2000/svg";
  const cx = 120, cy = 130, r = 95;
  const arc = (start, end) => {
    const toXY = a => [cx + r * Math.cos(a), cy + r * Math.sin(a)];
    const a0 = Math.PI + (start / 100) * Math.PI;
    const a1 = Math.PI + (end / 100) * Math.PI;
    const [x0, y0] = toXY(a0);
    const [x1, y1] = toXY(a1);
    return `M ${x0} ${y0} A ${r} ${r} 0 0 1 ${x1} ${y1}`;
  };
  const bg = document.createElementNS(ns, "path");
  bg.setAttribute("d", arc(0, 100));
  bg.setAttribute("stroke", "#1a2028"); bg.setAttribute("stroke-width", "14");
  bg.setAttribute("fill", "none"); bg.setAttribute("stroke-linecap", "round");
  gaugeSvg.appendChild(bg);
  const seg = (from, to, color) => {
    const p = document.createElementNS(ns, "path");
    p.setAttribute("d", arc(from, to)); p.setAttribute("stroke", color);
    p.setAttribute("stroke-width", "14"); p.setAttribute("fill", "none"); p.setAttribute("opacity", "0.9");
    gaugeSvg.appendChild(p);
  };
  seg(0, 33, "#3ddc84"); seg(33, 66, "#ffb340"); seg(66, 100, "#ff4d5e");
  const needle = document.createElementNS(ns, "line");
  needle.setAttribute("id", "gauge-needle");
  needle.setAttribute("x1", cx); needle.setAttribute("y1", cy);
  needle.setAttribute("x2", cx); needle.setAttribute("y2", cy - r + 18);
  needle.setAttribute("stroke", "#e9ecef"); needle.setAttribute("stroke-width", "3"); needle.setAttribute("stroke-linecap", "round");
  needle.style.transformOrigin = `${cx}px ${cy}px`;
  gaugeSvg.appendChild(needle);
  const hub = document.createElementNS(ns, "circle");
  hub.setAttribute("cx", cx); hub.setAttribute("cy", cy); hub.setAttribute("r", 6); hub.setAttribute("fill", "#e9ecef");
  gaugeSvg.appendChild(hub);
}
buildGaugeStatic();

function updateGauge(risk) {
  const angle = -90 + (risk / 100) * 180;
  document.getElementById("gauge-needle").style.transform = `rotate(${angle}deg)`;
  document.getElementById("gauge-value").textContent = Math.round(risk);
  const lvl = riskLevel(risk);
  const box = document.getElementById("gauge-level");
  box.textContent = `مستوى الخطر: ${lvl.label}`;
  box.style.color = colorFor(lvl.cls);
  box.style.borderColor = colorFor(lvl.cls);
}

/* ==========================================================================
   6) خط الرسم الزلزالي المتحرك (عنصر تصميمي في الشريط العلوي)
   ========================================================================== */
const seismoCanvas = document.getElementById("seismo-trace");
const sctx = seismoCanvas.getContext("2d");
let traceX = 0, lastY = null;
function resizeSeismoCanvas() {
  seismoCanvas.width = seismoCanvas.clientWidth * devicePixelRatio;
  seismoCanvas.height = seismoCanvas.clientHeight * devicePixelRatio;
}
window.addEventListener("resize", resizeSeismoCanvas);
resizeSeismoCanvas();
function drawSeismoFrame() {
  const w = seismoCanvas.width, h = seismoCanvas.height;
  const midY = h / 2;
  const amp = (h / 2 - 6) * (0.15 + globalRiskForTrace / 100);
  const y = midY + Math.sin(traceX * 0.09) * amp * 0.55 + (Math.random() - 0.5) * amp * 0.35;
  const imgData = sctx.getImageData(2, 0, w - 2, h);
  sctx.clearRect(0, 0, w, h);
  sctx.putImageData(imgData, 0, 0);
  sctx.strokeStyle = globalRiskForTrace > 66 ? "#ff4d5e" : globalRiskForTrace > 33 ? "#ffb340" : "#52c7ea";
  sctx.lineWidth = 1.4 * devicePixelRatio;
  sctx.beginPath();
  sctx.moveTo(w - 3, lastY === null ? y : lastY);
  sctx.lineTo(w - 1, y);
  sctx.stroke();
  lastY = y;
  traceX += 1;
  requestAnimationFrame(drawSeismoFrame);
}
requestAnimationFrame(drawSeismoFrame);

/* ==========================================================================
   7) عرض المؤشرات + السجل + الساعة
   ========================================================================== */
function renderWidgets() {
  const h = hotspots.find(s => s.id === selectedId);
  if (!h) return;
  document.getElementById("w-ssgi").textContent = h.astro.toFixed(2);
  document.getElementById("w-ssgi-bar").style.width = `${h.astro}%`;
  document.getElementById("w-pressure").textContent = h.current_pressure ? `${Math.round(h.current_pressure)} hPa` : "—";
  document.getElementById("w-pressure-bar").style.width = `${h.pressure}%`;
  const sign = h.thermal_anomaly >= 0 ? "+" : "";
  document.getElementById("w-thermal").textContent = h.thermal_anomaly != null ? `${sign}${h.thermal_anomaly.toFixed(1)}°C` : "—";
  document.getElementById("w-thermal-bar").style.width = `${h.thermal}%`;
  document.getElementById("selected-hotspot-name").textContent = h.name;
  document.getElementById("w-pressure-time").textContent = h.updated_at ? h.updated_at.split(" ")[1] || h.updated_at : "—";
}

async function renderAlerts() {
  try {
    const { alerts } = await fetchAlerts();
    const list = document.getElementById("alerts-list");
    document.getElementById("alerts-count").textContent = alerts.length;
    if (alerts.length === 0) {
      list.innerHTML = `<div class="alert-empty">لا توجد تنبيهات بعد — النظام يراقب البؤر النشطة...</div>`;
      return;
    }
    list.innerHTML = alerts.map(a => {
      const time = a.ts ? a.ts.split(" ")[1] || a.ts : "";
      const sent = a.telegram_sent ? " 📨" : "";
      return `<div class="alert-item level-${a.level}"><span class="alert-time">${time}${sent}</span>${a.message}</div>`;
    }).join("");
  } catch (err) {
    console.warn("alerts fetch failed", err);
  }
}

function updateClock() {
  document.getElementById("clock").textContent = new Date().toLocaleTimeString("en-GB");
}
setInterval(updateClock, 1000);
updateClock();

/* ==========================================================================
   8) اختيار البؤرة + أشرطة التمرير
   ========================================================================== */
function selectHotspot(id) {
  selectedId = id;
  if (markers[id]) markers[id].openPopup();
  renderWidgets();
  updateCharts();
}

function bindSlider(id, key) {
  const input = document.getElementById(id);
  const valEl = document.getElementById(id + "-val");
  input.addEventListener("change", async () => {
    weights[key] = Number(input.value);
    const w = normalizeWeights(weights);
    valEl.textContent = `${Math.round(w[key] * 100)}%`;
    refreshRiskDisplay();
    try {
      await saveWeights(weights);
    } catch (err) {
      alert("تعذر حفظ الأوزان: " + err.message);
    }
  });
  input.addEventListener("input", () => {
    weights[key] = Number(input.value);
    const w = normalizeWeights(weights);
    valEl.textContent = `${Math.round(w[key] * 100)}%`;
    refreshRiskDisplay();
  });
}
bindSlider("wt-tectonic", "tectonic");
bindSlider("wt-astro", "astro");
bindSlider("wt-thermal", "thermal");
bindSlider("wt-pressure", "pressure");

document.getElementById("reset-weights").addEventListener("click", async () => {
  weights = { tectonic: 50, astro: 25, thermal: 15, pressure: 10 };
  ["tectonic", "astro", "thermal", "pressure"].forEach(key => {
    const id = `wt-${key}`;
    document.getElementById(id).value = weights[key];
    document.getElementById(id + "-val").textContent = `${weights[key]}%`;
  });
  refreshRiskDisplay();
  if (currentUser) {
    try { await saveWeights(weights); } catch (err) { console.warn(err); }
  }
});

/* ==========================================================================
   9) دورة العرض + التهيئة
   ========================================================================== */
function refreshRiskDisplay() {
  const selected = hotspots.find(s => s.id === selectedId);
  if (!selected) return;
  const risk = computeTotalSeismicRiskIndex(selected, weights);
  globalRiskForTrace = risk;
  updateGauge(risk);
  updateMap();
  updateCharts();
  renderWidgets();
}

function setLoading(text) {
  document.getElementById("loading-text").textContent = text;
}

async function loadHotspotsAndWeights() {
  const data = await fetchHotspots();
  hotspots = data.hotspots;
  weights = { tectonic: data.weights.tectonic, astro: data.weights.astro, thermal: data.weights.thermal, pressure: data.weights.pressure };
  ["tectonic", "astro", "thermal", "pressure"].forEach(key => {
    const id = `wt-${key}`;
    const w = normalizeWeights(weights);
    document.getElementById(id).value = weights[key];
    document.getElementById(id + "-val").textContent = `${Math.round(w[key] * 100)}%`;
  });
  document.getElementById("quake-source-time").textContent = new Date().toLocaleString("en-GB");
}

async function init() {
  try {
    setLoading("جاري تسجيل الدخول التلقائي (إن وُجدت جلسة سابقة)...");
    try {
      const { user } = await fetchMe();
      onAuthChanged(user);
    } catch { onAuthChanged(null); }

    setLoading("جاري جلب البؤر الزلزالية من خادم Seismic Nexus API...");
    await loadHotspotsAndWeights();

    if (hotspots.length === 0) {
      setLoading("⚠️ الخادم لم يجهّز البيانات بعد. انتظر دقيقة ثم أعد تحميل الصفحة (المحرك الخلفي يجلب البيانات عند أول تشغيل).");
      return;
    }

    selectedId = hotspots[0].id;
    buildMapMarkers();
    selectHotspot(selectedId);
    refreshRiskDisplay();
    renderAlerts();

    document.getElementById("loading-overlay").classList.add("hidden");

    setInterval(async () => {
      await loadHotspotsAndWeights();
      refreshRiskDisplay();
    }, 30 * 1000); // نجلب أحدث حالة من خادمنا كل 30 ثانية

    setInterval(renderAlerts, 20 * 1000);
  } catch (err) {
    console.error(err);
    setLoading("⚠️ تعذّر الاتصال بخادم Seismic Nexus API. تأكد أن الخادم الخلفي (backend) يعمل على المنفذ الصحيح، ثم أعد تحميل الصفحة.");
  }
}

init();
